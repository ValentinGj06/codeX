<?php $__env->startSection('title', 'Edit'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <form method="POST" action="/companies/<?php echo e($company->id); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PATCH')); ?>

        <div class="form-group row">
            <label for="name" class="col-sm-2 col-form-label">Company Name</label>
            <div class="col-sm-3">   
                <input type="text" name="name" class="form-control" placeholder="Company Name" value="<?php echo e($company->name); ?>" required>
            </div>
        </div>
        <div class="form-group row">
            <label for="email" class="col-sm-2 col-form-label">Email address</label>
            <div class="col-sm-3">
                <input type="email" name="email" class="form-control" placeholder="Company Email" value="<?php echo e($company->email); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="logo" class="col-sm-2 col-form-label">Logo</label>
            <div class="col-sm-3">
                <input type="file" class="form-control form-control-file" name="logo" value="<?php echo e($company->logo); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="website" class="col-sm-2 col-form-label">Company Website</label>
            <div class="col-sm-3">
                <input type="text" name="website" class="form-control" placeholder="Company Website" value="<?php echo e($company->website); ?>">
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-2">
                <button type="submit" class="btn btn-block btn-primary">Update Company</button>
            </div>
            <div class="col-sm-2">
                <button type="submit" form="delete_company" class="btn btn-danger">Delete</button>
            </div>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-warning" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </form>
</div>
<form action="/companies/<?php echo e($company->id); ?>" id="delete_company" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/companies/edit.blade.php ENDPATH**/ ?>