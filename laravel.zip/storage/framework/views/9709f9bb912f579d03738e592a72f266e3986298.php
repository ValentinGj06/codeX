<?php $__env->startSection('title', 'Company'); ?>


<?php $__env->startSection('content'); ?>
    <h1 class="title"><?php echo e($company->name); ?></h1>

    <button class="btn btn-primary" form="add_employee">Add New Employee</button>
    <form action="/<?php echo e($company->id); ?>/employees/create" id="add_employee" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="company_id" value="<?php echo e($company->id); ?>">
    </form>
    <?php if($employee): ?>
    <h1 class="title">Employees</h1>
    
    <table class="table table-striped">
         <thead>
         <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Actions</th>
         </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                   <td><?php echo e($employees->id); ?></td>
                   <td><?php echo e($employees->first_name); ?></td>
                   <td><?php echo e($employees->last_name); ?></td>
                   <td><?php echo e($employees->email); ?></td>
                   <td><?php echo e($employees->phone); ?></td>
                   <td>
                        <a href="/employees/<?php echo e($employees->id); ?>"><button class="btn btn-primary">View</button></a>
                        <a href="/employees/<?php echo e($employees->id); ?>/edit"><button class="btn btn-primary">Edit</button></a>
                        <a href="/employees/<?php echo e($employees->id); ?>/delete"><button class="btn btn-primary">Delete</button></a>
                   </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
      <?php echo e($employee->links()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/companies/show.blade.php ENDPATH**/ ?>