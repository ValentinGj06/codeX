<?php $__env->startSection('title', 'Employees'); ?>


<?php $__env->startSection('content'); ?>
    <h1 class="title">Employees</h1>
    
    <table class="table table-striped">
         <thead>
         <tr>
            <th>ID</th>
            <th>Company</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
         </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                   <td><?php echo e($employee->id); ?></td>
                   <td><?php echo e($employee->company->name); ?></td>
                   <td><?php echo e($employee->first_name); ?></td>
                   <td><?php echo e($employee->email); ?></td>
                   <td>
                        <a href="/employees/<?php echo e($employee->id); ?>"><button class="btn btn-primary">View</button></a>
                        <a href="/employees/<?php echo e($employee->id); ?>/edit"><button class="btn btn-primary">Edit</button></a>
                        <a href="/employees/<?php echo e($employee->id); ?>/delete"><button class="btn btn-primary">Delete</button></a>
                   </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/employees/index.blade.php ENDPATH**/ ?>