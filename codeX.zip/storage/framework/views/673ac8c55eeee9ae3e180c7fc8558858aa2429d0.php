<?php $__env->startSection('title', 'Employee'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="title"><?php echo e($employee->first_name); ?></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/employees/show.blade.php ENDPATH**/ ?>