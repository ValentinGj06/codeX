<?php $__env->startSection('title', 'Add'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="title">Add New Employee</h1>
    <form method="POST" action="/employees">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="company_id" value="<?php echo e($company->id); ?>">
        <div class="form-group row">
            <label for="first_name" class="col-sm-2 col-form-label">First Name</label>
            <div class="col-sm-3">   
                <input type="text" name="first_name" class="form-control" placeholder="First Name" value="<?php echo e(old('first_name')); ?>" required>
            </div>
        </div>
        <div class="form-group row">
            <label for="last_name" class="col-sm-2 col-form-label">Last Name</label>
            <div class="col-sm-3">   
                <input type="text" name="last_name" class="form-control" placeholder="Last Name" value="<?php echo e(old('last_name')); ?>" required>
            </div>
        </div>
        <div class="form-group row">
            <label for="email" class="col-sm-2 col-form-label">Email address</label>
            <div class="col-sm-3">
                <input type="email" name="email" class="form-control" placeholder="Employee Email" value="<?php echo e(old('email')); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="phone" class="col-sm-2 col-form-label">Phone</label>
            <div class="col-sm-3">
                <input type="text" class="form-control" name="phone" placeholder="Phone Number" value="<?php echo e(old('phone')); ?>">
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-2">
                <button type="submit" class="btn btn-primary">Add Employee</button>
            </div>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-warning" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/employees/create.blade.php ENDPATH**/ ?>