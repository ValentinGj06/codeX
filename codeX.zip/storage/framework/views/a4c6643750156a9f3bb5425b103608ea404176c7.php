<?php $__env->startSection('title', 'Companies'); ?>


<?php $__env->startSection('content'); ?>
    <h1 class="title">Companies</h1>

    <a class="nav-item nav-link" href="/companies/create"><button class="btn btn-primary" form="add_employee">Add New Company</button></a>
    <table class="table table-striped">
         <thead>
         <tr>
            <th>ID</th>
            <th>Logo</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
         </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                   <td><?php echo e($company->id); ?></td>
                   <td><img src="<?php echo e(asset("storage/images/$company->logo")); ?>"></td>
                   <td><?php echo e($company->name); ?></td>
                   <td><?php echo e($company->email); ?></td>
                   <td>
                        <a href="/companies/<?php echo e($company->id); ?>"><button class="btn btn-primary">View</button></a>
                        <a href="/companies/<?php echo e($company->id); ?>/edit"><button class="btn btn-primary">Edit</button></a>
                        <a href="/companies/<?php echo e($company->id); ?>/delete"><button class="btn btn-primary">Delete</button></a>
                   </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
      <?php echo e($companies->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/companies/index.blade.php ENDPATH**/ ?>